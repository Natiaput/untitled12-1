import StepObject.RegistrationSteps;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import static Utils.BrowserActions.driver;

public class RegistrationTest {

    @Test
    public void registrationCorrectData() {
        RegistrationSteps step1 = new RegistrationSteps(driver);
        step1.userFieldActions("Natia123456");
        step1.passwordFieldActions("Mia123456");
        step1.password1FieldActions("Mia123456");
        step1.idNUmberFieldActions("01021015578");
        step1.phoneNumberFieldActions("5990123456");
        step1.confirmButtonFieldActions();

        // Simulate receiving OTP via SMS (replace with actual implementation)
        String phoneOtp = receiveOtpViaSms("userPhoneNumber");
        step1.enterPhoneOtp(phoneOtp);

        step1.emailFieldActions("Natia_futkaradze@yahoo.com");
        step1.confirmButton1FieldActions();

        // Simulate receiving OTP via email (replace with actual implementation)
        String emailOtp = receiveOtpViaEmail("userEmail");
        step1.enterEmailOtp(emailOtp);

        step1.registrationButtonFieldActions();

        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        Assert.assertTrue(isRegistrationSuccessful(), "Registration was not successful.");
    }

    private boolean isRegistrationSuccessful() {
        return driver.findElement(By.id("successMessage")).isDisplayed();
    }

    private String receiveOtpViaSms(String phoneNumber) {
        return "123456";
    }

    private String receiveOtpViaEmail(String emailAddress) {
        return "654321";
    }

    @Test
    public void registrationIncorrectUserData() throws InterruptedException {
        RegistrationSteps step1 = new RegistrationSteps(driver);
        step1.userFieldActions("123456");
        step1.passwordFieldActions("Mia123456");
        step1.password1FieldActions("Mia123456");
        step1.idNUmberFieldActions("01021015578");
        step1.phoneNumberFieldActions("599012345");
        step1.emailFieldActions("Natia_futkaradze@yahoo.com");
        step1.registrationButtonFieldActions();
        Thread.sleep(5000);

        Assert.assertTrue(isErrorMessageDisplayed(), "Error message not displayed for incorrect user data.");
    }

    @Test
    public void registrationIncorrectIdNumberData() {
        RegistrationSteps step1 = new RegistrationSteps(driver);
        step1.userFieldActions("Natia12345");
        step1.passwordFieldActions("Mia123456");
        step1.password1FieldActions("Mia123456");
        step1.idNUmberFieldActions("0000000000000000000");
        step1.phoneNumberFieldActions("599012345");
        step1.emailFieldActions("Natia_futkaradze@yahoo.com");
        step1.registrationButtonFieldActions();
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        Assert.assertTrue(isErrorMessageDisplayed(), "Error message not displayed for incorrect ID number data.");
    }

    @Test
    public void registrationIncorrectEmailData() throws InterruptedException {
        RegistrationSteps step1 = new RegistrationSteps(driver);
        step1.userFieldActions("Natia123456");
        step1.passwordFieldActions("Mia123456");
        step1.password1FieldActions("Mia123456");
        step1.idNUmberFieldActions("01021015578");
        step1.phoneNumberFieldActions("599012345");
        step1.emailFieldActions("natia@ybs.com");
        step1.registrationButtonFieldActions();
        Thread.sleep(3000);

        Assert.assertTrue(isErrorMessageDisplayed(), "Error message not displayed for incorrect email data.");
    }

    @Test
    public void registrationIncorrectPasswordData() throws InterruptedException {
        RegistrationSteps step1 = new RegistrationSteps(driver);
        step1.userFieldActions("Natia123456");
        step1.passwordFieldActions("Mia123456");
        step1.password1FieldActions("@@@@@@");
        step1.idNUmberFieldActions("01021015578");
        step1.phoneNumberFieldActions("599012345");
        step1.emailFieldActions("Natia_futkaradze@yahoo.com");
        step1.registrationButtonFieldActions();
        Thread.sleep(3000);

        Assert.assertTrue(isErrorMessageDisplayed(), "Error message not displayed for incorrect password data.");
    }

    @Test
    public void registrationEmptyData() {
        RegistrationSteps step1 = new RegistrationSteps(driver);
        step1.userFieldActions("");
        step1.passwordFieldActions("");
        step1.password1FieldActions("");
        step1.idNUmberFieldActions("");
        step1.phoneNumberFieldActions("");
        step1.emailFieldActions("");
        step1.registrationButtonFieldActions();
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        Assert.assertTrue(isErrorMessageDisplayed(), "Error message not displayed for empty data.");
    }

    @Test
    public void registrationEmptyUserAndEmailData() throws InterruptedException {
        RegistrationSteps step1 = new RegistrationSteps(driver);
        step1.userFieldActions("");
        step1.passwordFieldActions("Mia123456");
        step1.password1FieldActions("Mia123456");
        step1.idNUmberFieldActions("12001094450");
        step1.phoneNumberFieldActions("599012345");
        step1.emailFieldActions("");
        step1.registrationButtonFieldActions();
        Thread.sleep(3000);
        Assert.assertTrue(isErrorMessageDisplayed(), "User already registered!");
    }

    @Test
    public void registrationEmptyIdNumberData() {
        RegistrationSteps step1 = new RegistrationSteps(driver);
        step1.userFieldActions("Natia123456");
        step1.passwordFieldActions("Mia12345");
        step1.password1FieldActions("Mia@12345");
        step1.idNUmberFieldActions("");
        step1.phoneNumberFieldActions("599012345");
        step1.emailFieldActions("Natia_futkaradze@yahoo.com");
        step1.registrationButtonFieldActions();
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        Assert.assertTrue(isErrorMessageDisplayed(), "Error message not displayed for empty ID number data.");
    }

    @Test
    public void registrationIncorrectPasswordsData() throws InterruptedException {
        RegistrationSteps step1 = new RegistrationSteps(driver);
        step1.userFieldActions("Natia123456");
        step1.passwordFieldActions("Mia123456");
        step1.password1FieldActions("Mqoqqq");
        step1.idNUmberFieldActions("12001094450");
        step1.phoneNumberFieldActions("!!!!!!!!!!!!!!!!!!!!");
        step1.emailFieldActions("Natia_futkaradze@yahoo.com");
        step1.registrationButtonFieldActions();
        Thread.sleep(3000);

        Assert.assertTrue(isErrorMessageDisplayed(), "Error message not displayed for incorrect passwords data.");
    }

    @Test
    public void registrationEmptyPasswordField() throws InterruptedException {
        RegistrationSteps step1 = new RegistrationSteps(driver);
        step1.userFieldActions("Natia123456");
        step1.passwordFieldActions("");
        step1.password1FieldActions("Mia123456");
        step1.idNUmberFieldActions("12001094450");
        step1.phoneNumberFieldActions("599012345");
        step1.emailFieldActions("Natia_futkaradze@yahoo.com");
        step1.registrationButtonFieldActions();
        Thread.sleep(3000);

        Assert.assertTrue(isErrorMessageDisplayed(), "Error message not displayed for empty password field.");
    }

    private boolean isErrorMessageDisplayed() {
        return driver.findElements(By.id("errorMessage")).size() > 0;
    }
}
